#!/usr/bin/env bash
set -euo pipefail

# export_copilot_pack.sh
# Creates a single ZIP package for Copilot review.
# Output: exports/<repo>_copilot_pack_<timestamp>.zip

ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
cd "$ROOT"

REPO_NAME="$(basename "$ROOT")"
TS="$(date +%Y%m%d_%H%M%S)"
OUT_DIR="$ROOT/exports"
OUT_ZIP="$OUT_DIR/${REPO_NAME}_copilot_pack_${TS}.zip"
MANIFEST="$OUT_DIR/${REPO_NAME}_copilot_pack_${TS}_MANIFEST.md"

mkdir -p "$OUT_DIR"

GIT_HEAD="N/A"
if git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  GIT_HEAD="$(git rev-parse HEAD)"
fi

cat > "$MANIFEST" <<EOF
<!--
Authoritative runtime document.
If it’s not described here, it’s not supported.
-->

# Copilot Review Package Manifest

Generated: $(date)
Repository: $REPO_NAME
Git HEAD: $GIT_HEAD

Included:
- README.md
- INDEX.md
- runbooks/**
- templates/**
- scripts/**
- .github/workflows/**

Excluded:
- .git/**
- exports/**
EOF

python3 <<PY
from pathlib import Path
import zipfile

root = Path("$ROOT")
out_zip = Path("$OUT_ZIP")

include_dirs = [
    "runbooks",
    "templates",
    "scripts",
    ".github/workflows",
]

include_files = [
    "README.md",
    "INDEX.md",
]

with zipfile.ZipFile(out_zip, "w", zipfile.ZIP_DEFLATED) as z:
    for rel in include_files:
        p = root / rel
        if p.exists():
            z.write(p, p.relative_to(root))

    for d in include_dirs:
        base = root / d
        if not base.exists():
            continue
        for f in base.rglob("*"):
            if f.is_dir():
                continue
            rel = f.relative_to(root)
            if rel.parts[0] in {".git", "exports"}:
                continue
            z.write(f, rel)

    z.write(Path("$MANIFEST"), Path("$MANIFEST").relative_to(root))

print(f"[OK] Created: {out_zip}")
PY